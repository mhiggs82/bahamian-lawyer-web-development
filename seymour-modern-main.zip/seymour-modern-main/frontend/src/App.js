import { useState, useEffect } from "react";
import "@/App.css";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Building2, 
  Briefcase, 
  Scale, 
  Users, 
  Plane, 
  FileText, 
  Menu, 
  X, 
  Phone, 
  Mail, 
  MapPin,
  ChevronRight,
  Award,
  Shield,
  Clock,
  ArrowRight,
  Quote,
  Star,
  ChevronLeft,
  ExternalLink,
  Flag,
  CheckCircle2,
  Globe
} from "lucide-react";

// Image URLs from design guidelines
const IMAGES = {
  hero: "https://images.unsplash.com/photo-1591303239195-df6ed4eb91c7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA4Mzl8MHwxfHNlYXJjaHwzfHxjYWxtJTIwb2NlYW4lMjBob3Jpem9uJTIwYmFoYW1hcyUyMG1vb2R5fGVufDB8fHx8MTc3MjgxMzE4Nnww&ixlib=rb-4.1.0&q=85",
  legacy: "https://images.unsplash.com/photo-1661064343945-38b0721aae15?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzN8MHwxfHNlYXJjaHwyfHxuYXNzYXUlMjBiYWhhbWFzJTIwZ292ZXJubWVudCUyMGhvdXNlJTIwY29sb25pYWwlMjBhcmNoaXRlY3R1cmV8ZW58MHx8fHwxNzcyODEzMTg1fDA&ixlib=rb-4.1.0&q=85",
  nassau: "https://images.unsplash.com/photo-1597254490689-0b195e74941f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzl8MHwxfHNlYXJjaHwxfHxuYXNzYXUlMjBiYWhhbWFzJTIwcGFybGlhbWVudCUyMHNxdWFyZSUyMHBpbmslMjBidWlsZGluZ3xlbnwwfHx8fDE3NzI4MTMyMzh8MA&ixlib=rb-4.1.0&q=85",
  columns: "https://images.unsplash.com/photo-1765788819823-18e729eb2ea8?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2Mzl8MHwxfHNlYXJjaHwzfHxuZW9jbGFzc2ljYWwlMjBidWlsZGluZyUyMGNvbHVtbnMlMjBzdG9uZSUyMGRldGFpbHxlbnwwfHx8fDE3NzI4MTMxOTl8MA&ixlib=rb-4.1.0&q=85",
};

// Practice areas data
const practiceAreas = [
  { 
    id: 1, 
    title: "Real Estate & Mortgages", 
    description: "Comprehensive legal support for property transactions, conveyancing, and mortgage documentation across The Bahamas.",
    icon: Building2 
  },
  { 
    id: 2, 
    title: "Company & Commercial", 
    description: "Corporate formation, mergers, acquisitions, and ongoing commercial legal advisory for local and international businesses.",
    icon: Briefcase 
  },
  { 
    id: 3, 
    title: "Litigation & Winding Up", 
    description: "Skilled representation in commercial disputes, debt recovery, and corporate insolvency proceedings.",
    icon: Scale 
  },
  { 
    id: 4, 
    title: "Employment Law", 
    description: "Expert guidance on employment contracts, workplace disputes, and regulatory compliance.",
    icon: Users 
  },
  { 
    id: 5, 
    title: "Immigration Services", 
    description: "Residency permits, work permits, and citizenship applications handled with precision and care.",
    icon: Plane 
  },
  { 
    id: 6, 
    title: "Probates & Estates", 
    description: "Estate planning, will preparation, and probate administration to protect your legacy.",
    icon: FileText 
  },
];

// Trust Seals / Affiliations data
const trustSeals = [
  {
    id: 1,
    name: "U.S. Embassy Nassau",
    subtitle: "Recommended Attorney",
    description: "Listed on the U.S. Embassy's official roster of recommended legal service providers for American citizens.",
    year: "Since 2008",
    featured: true
  },
  {
    id: 2,
    name: "The Bahamas Bar Association",
    subtitle: "Licensed Members",
    description: "All attorneys are fully licensed members in good standing with The Bahamas Bar Association.",
    year: "Since 1995",
    featured: false
  },
  {
    id: 3,
    name: "Caribbean Association of Banks",
    subtitle: "Legal Partner",
    description: "Trusted legal counsel for banking and financial institutions across the Caribbean region.",
    year: "Since 2003",
    featured: false
  },
  {
    id: 4,
    name: "International Bar Association",
    subtitle: "Member Firm",
    description: "Connected to a global network of legal professionals through IBA membership.",
    year: "Since 2010",
    featured: false
  },
  {
    id: 5,
    name: "Bahamas Real Estate Association",
    subtitle: "Approved Legal Provider",
    description: "Recognized provider for real estate transactions and property conveyancing services.",
    year: "Since 1998",
    featured: false
  },
  {
    id: 6,
    name: "Caribbean Law Institute",
    subtitle: "Contributing Member",
    description: "Active participant in advancing legal scholarship and practice across the Caribbean.",
    year: "Since 2015",
    featured: false
  }
];

// Testimonials data
const testimonials = [
  {
    id: 1,
    name: "Michael R. Thompson",
    role: "CEO, Atlantic Ventures",
    location: "Miami, FL",
    quote: "Seymour Law guided us through a complex real estate acquisition in Nassau with exceptional professionalism. Their knowledge of both U.S. and Bahamian legal frameworks was invaluable.",
    rating: 5,
    isUSEmbassyReferred: true
  },
  {
    id: 2,
    name: "Sarah J. Williams",
    role: "Managing Director, Caribbean Holdings Ltd.",
    location: "New York, NY",
    quote: "When the U.S. Embassy recommended Seymour Law for our corporate restructuring, we knew we were in good hands. They exceeded every expectation.",
    rating: 5,
    isUSEmbassyReferred: true
  },
  {
    id: 3,
    name: "David & Elizabeth Chen",
    role: "Private Investors",
    location: "San Francisco, CA",
    quote: "The immigration team made our permanent residency process seamless. Their attention to detail and clear communication gave us complete peace of mind.",
    rating: 5,
    isUSEmbassyReferred: true
  },
  {
    id: 4,
    name: "Robert Hartley III",
    role: "Founder, Hartley Family Office",
    location: "Boston, MA",
    quote: "For three generations, Seymour Law has handled our family's estate planning in The Bahamas. Their discretion and expertise are unmatched.",
    rating: 5,
    isUSEmbassyReferred: false
  },
  {
    id: 5,
    name: "Jennifer Martinez",
    role: "VP Operations, Global Marine Corp",
    location: "Houston, TX",
    quote: "Outstanding litigation support during a complex commercial dispute. The U.S. Embassy's recommendation was spot-on. Highly professional team.",
    rating: 5,
    isUSEmbassyReferred: true
  }
];

// Case Studies data
const caseStudies = [
  {
    id: 1,
    title: "Multi-Million Dollar Resort Acquisition",
    category: "Real Estate & Commercial",
    description: "Successfully represented a U.S.-based investment consortium in the $47M acquisition of a beachfront resort property, including due diligence, title verification, and complex financing arrangements.",
    outcome: "Transaction completed 3 weeks ahead of schedule",
    isUSEmbassyReferred: true,
    icon: Building2
  },
  {
    id: 2,
    title: "Corporate Restructuring for International Expansion",
    category: "Company & Commercial",
    description: "Advised a Fortune 500 subsidiary on restructuring its Bahamian operations to optimize for international tax treaties while maintaining full regulatory compliance.",
    outcome: "Annual savings of $2.3M in operational costs",
    isUSEmbassyReferred: true,
    icon: Globe
  },
  {
    id: 3,
    title: "High-Net-Worth Immigration Portfolio",
    category: "Immigration Services",
    description: "Managed permanent residency applications for 12 U.S. families relocating to The Bahamas, coordinating with the U.S. Embassy and Bahamian Immigration authorities.",
    outcome: "100% approval rate with average 4-month processing",
    isUSEmbassyReferred: true,
    icon: Plane
  },
  {
    id: 4,
    title: "Complex Estate Administration",
    category: "Probates & Estates",
    description: "Administered a cross-border estate valued at $28M involving properties in Nassau, Exuma, and Florida, navigating both Bahamian and U.S. probate requirements.",
    outcome: "Estate fully distributed within 18 months",
    isUSEmbassyReferred: false,
    icon: FileText
  }
];

// Animation variants
const fadeUpVariant = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

// Navbar Component
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "#practice-areas", label: "Practice Areas" },
    { href: "#about", label: "Our Legacy" },
    { href: "#testimonials", label: "Testimonials" },
    { href: "#case-studies", label: "Case Studies" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <nav 
      data-testid="navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "nav-glass border-b border-limestone/50 py-4" : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo */}
        <a href="#" data-testid="logo" className="flex items-center gap-3">
          <div className="w-10 h-10 bg-navy flex items-center justify-center">
            <span className="text-gold font-serif text-xl font-bold">S</span>
          </div>
          <div className="hidden sm:block">
            <span className={`font-serif text-xl tracking-tight ${isScrolled ? "text-navy" : "text-white"}`}>
              Seymour Law
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              data-testid={`nav-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
              className={`gold-underline text-sm font-medium tracking-wide transition-colors ${
                isScrolled ? "text-navy-light hover:text-navy" : "text-white/90 hover:text-white"
              }`}
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contact"
            data-testid="nav-consultation-btn"
            className="bg-gold text-navy px-6 py-3 text-xs font-semibold uppercase tracking-[0.15em] hover:bg-gold-light transition-colors"
          >
            Request Consultation
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          data-testid="mobile-menu-btn"
          className="md:hidden p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
        >
          {isMobileMenuOpen ? (
            <X className={isScrolled ? "text-navy" : "text-white"} size={24} />
          ) : (
            <Menu className={isScrolled ? "text-navy" : "text-white"} size={24} />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            data-testid="mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-alabaster border-t border-limestone"
          >
            <div className="px-6 py-6 space-y-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  data-testid={`mobile-nav-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                  className="block text-navy font-medium py-2 border-b border-limestone/50"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#contact"
                data-testid="mobile-consultation-btn"
                className="block bg-navy text-white text-center py-4 text-sm font-semibold uppercase tracking-[0.15em] mt-4"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Request Consultation
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

// Hero Section
const HeroSection = () => {
  return (
    <section data-testid="hero-section" className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src={IMAGES.hero} 
          alt="Bahamian ocean horizon" 
          className="w-full h-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 pt-32 pb-20">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="max-w-3xl"
        >
          {/* Label */}
          <motion.p
            variants={fadeUpVariant}
            className="text-gold text-xs font-semibold uppercase tracking-[0.25em] mb-6"
          >
            Established 1995 · Nassau, Bahamas
          </motion.p>

          {/* Main Heading */}
          <motion.h1
            variants={fadeUpVariant}
            className="font-serif text-5xl md:text-7xl text-white tracking-tight leading-[1.1] mb-8"
          >
            Commercial Excellence.<br />
            <span className="text-gold">Bahamian Legacy.</span>
          </motion.h1>

          {/* Subheading */}
          <motion.p
            variants={fadeUpVariant}
            className="text-white/80 text-lg md:text-xl font-light leading-relaxed mb-10 max-w-xl"
          >
            Three decades of trusted legal counsel serving businesses, investors, 
            and families across The Bahamas with personalized attention and world-class expertise.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            variants={fadeUpVariant}
            className="flex flex-col sm:flex-row gap-4"
          >
            <a
              href="#contact"
              data-testid="hero-cta-primary"
              className="btn-primary bg-gold text-navy px-8 py-4 text-sm font-semibold uppercase tracking-[0.15em] hover:bg-gold-light transition-all inline-flex items-center justify-center gap-2"
            >
              Schedule Consultation
              <ArrowRight size={16} />
            </a>
            <a
              href="#practice-areas"
              data-testid="hero-cta-secondary"
              className="border border-white/30 text-white px-8 py-4 text-sm font-semibold uppercase tracking-[0.15em] hover:bg-white/10 transition-all text-center"
            >
              Our Practice Areas
            </a>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="flex flex-col items-center gap-2 text-white/50">
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-px h-8 bg-gradient-to-b from-white/50 to-transparent"
          />
        </div>
      </motion.div>
    </section>
  );
};

// Practice Areas Section
const PracticeAreasSection = () => {
  return (
    <section id="practice-areas" data-testid="practice-areas-section" className="py-24 md:py-32 bg-alabaster">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUpVariant}
          className="mb-16 md:mb-20"
        >
          <p className="text-gold text-xs font-semibold uppercase tracking-[0.25em] mb-4">
            Areas of Expertise
          </p>
          <h2 className="font-serif text-4xl md:text-5xl text-navy tracking-tight mb-6">
            Practice Areas
          </h2>
          <div className="gold-line" />
        </motion.div>

        {/* Practice Areas Grid */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {practiceAreas.map((area) => {
            const IconComponent = area.icon;
            return (
              <motion.article
                key={area.id}
                variants={fadeUpVariant}
                data-testid={`practice-area-${area.id}`}
                className="practice-card group p-8 bg-white border border-limestone hover:border-gold/30 transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-navy/5 group-hover:bg-gold/10 transition-colors">
                    <IconComponent className="text-gold" size={24} />
                  </div>
                </div>
                <h3 className="font-serif text-xl text-navy mb-3">
                  {area.title}
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed mb-4">
                  {area.description}
                </p>
                <a 
                  href="#contact" 
                  className="inline-flex items-center gap-2 text-navy text-sm font-medium group-hover:text-gold transition-colors"
                >
                  Learn More <ChevronRight size={14} />
                </a>
              </motion.article>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

// About/Legacy Section
const AboutSection = () => {
  return (
    <section id="about" data-testid="about-section" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Column */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUpVariant}
            className="relative"
          >
            <div className="img-zoom">
              <img
                src={IMAGES.legacy}
                alt="Historic Nassau colonial architecture"
                className="w-full aspect-[4/5] object-cover"
              />
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -right-6 md:right-8 bg-navy p-6 md:p-8">
              <p className="text-gold font-serif text-4xl md:text-5xl font-bold">30+</p>
              <p className="text-white/80 text-sm uppercase tracking-wider mt-1">Years of Service</p>
            </div>
          </motion.div>

          {/* Content Column */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.p
              variants={fadeUpVariant}
              className="text-gold text-xs font-semibold uppercase tracking-[0.25em] mb-4"
            >
              Our Legacy
            </motion.p>
            <motion.h2
              variants={fadeUpVariant}
              className="font-serif text-4xl md:text-5xl text-navy tracking-tight mb-6"
            >
              A Tradition of Legal Excellence
            </motion.h2>
            <motion.div variants={fadeUpVariant} className="gold-line mb-8" />
            
            <motion.p
              variants={fadeUpVariant}
              className="text-slate-600 text-lg leading-relaxed mb-6"
            >
              Since 1995, Seymour Law has been a cornerstone of commercial legal services in 
              The Bahamas. Our firm was founded on the principles of integrity, expertise, 
              and personalized client service that continue to guide us today.
            </motion.p>
            
            <motion.p
              variants={fadeUpVariant}
              className="text-slate-600 leading-relaxed mb-8"
            >
              With deep roots in Nassau and an understanding of both Bahamian and international 
              legal frameworks, we provide sophisticated counsel to local businesses, international 
              investors, and families seeking to establish their presence in this beautiful archipelago.
            </motion.p>

            <motion.div
              variants={fadeUpVariant}
              className="flex items-center gap-4"
            >
              <img
                src={IMAGES.nassau}
                alt="Nassau Parliament Square"
                className="w-20 h-20 object-cover"
              />
              <div>
                <p className="text-navy font-medium">Located in the Heart of Nassau</p>
                <p className="text-slate-500 text-sm">Steps from Government House & Parliament Square</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Why Choose Us Section
const WhyUsSection = () => {
  const reasons = [
    {
      icon: Award,
      title: "Proven Expertise",
      description: "Three decades of successful outcomes in complex commercial matters."
    },
    {
      icon: Shield,
      title: "Client Confidentiality",
      description: "Absolute discretion in handling sensitive business and personal affairs."
    },
    {
      icon: Clock,
      title: "Responsive Service",
      description: "Timely communication and dedicated attention to every matter."
    }
  ];

  return (
    <section id="why-us" data-testid="why-us-section" className="py-24 md:py-32 bg-navy relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src={IMAGES.columns} 
          alt="" 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.p
              variants={fadeUpVariant}
              className="text-gold text-xs font-semibold uppercase tracking-[0.25em] mb-4"
            >
              Why Seymour Law
            </motion.p>
            <motion.h2
              variants={fadeUpVariant}
              className="font-serif text-4xl md:text-5xl text-white tracking-tight mb-6"
            >
              Your Trusted Partner in <span className="text-gold">Commercial Law</span>
            </motion.h2>
            <motion.div variants={fadeUpVariant} className="w-16 h-0.5 bg-gold mb-8" />
            
            <motion.p
              variants={fadeUpVariant}
              className="text-white/70 text-lg leading-relaxed mb-10"
            >
              We combine deep local knowledge with international standards to deliver 
              legal solutions that protect your interests and advance your goals.
            </motion.p>

            <motion.div variants={staggerContainer} className="space-y-6">
              {reasons.map((reason, index) => {
                const IconComponent = reason.icon;
                return (
                  <motion.div
                    key={index}
                    variants={fadeUpVariant}
                    data-testid={`why-us-reason-${index + 1}`}
                    className="flex gap-4"
                  >
                    <div className="w-12 h-12 flex-shrink-0 bg-gold/20 flex items-center justify-center">
                      <IconComponent className="text-gold" size={20} />
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">{reason.title}</h3>
                      <p className="text-white/60 text-sm">{reason.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-2 gap-6"
          >
            {[
              { number: "500+", label: "Cases Handled" },
              { number: "30+", label: "Years Experience" },
              { number: "98%", label: "Client Satisfaction" },
              { number: "6", label: "Practice Areas" }
            ].map((stat, index) => (
              <motion.div
                key={index}
                variants={fadeUpVariant}
                data-testid={`stat-${index + 1}`}
                className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 text-center"
              >
                <p className="font-serif text-4xl md:text-5xl text-gold mb-2">{stat.number}</p>
                <p className="text-white/60 text-sm uppercase tracking-wider">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Trust Seals Section
const TrustSealsSection = () => {
  return (
    <section id="affiliations" data-testid="trust-seals-section" className="py-20 md:py-24 bg-alabaster border-y border-limestone/50">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUpVariant}
          className="text-center mb-12"
        >
          <p className="text-gold text-xs font-semibold uppercase tracking-[0.25em] mb-3">
            Trusted & Recognized
          </p>
          <h2 className="font-serif text-3xl md:text-4xl text-navy tracking-tight">
            Official Affiliations & Accreditations
          </h2>
        </motion.div>

        {/* Featured Seal - U.S. Embassy */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUpVariant}
          className="mb-12"
        >
          <div 
            data-testid="trust-seal-featured"
            className="bg-navy p-8 md:p-10 flex flex-col md:flex-row items-center gap-6 md:gap-10"
          >
            {/* Embassy Seal */}
            <div className="flex-shrink-0">
              <div className="w-24 h-24 md:w-28 md:h-28 bg-white/10 rounded-full flex items-center justify-center border-2 border-gold">
                <div className="text-center">
                  <Flag className="text-gold mx-auto mb-1" size={32} />
                  <span className="text-white text-[10px] font-bold uppercase tracking-wider">USA</span>
                </div>
              </div>
            </div>
            
            {/* Content */}
            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4 mb-3">
                <h3 className="font-serif text-2xl md:text-3xl text-white">
                  U.S. Embassy Nassau
                </h3>
                <span className="inline-block bg-gold text-navy px-3 py-1 text-xs font-bold uppercase tracking-wider">
                  Recommended Attorney
                </span>
              </div>
              <p className="text-white/70 leading-relaxed max-w-2xl">
                Seymour Law is proudly listed on the United States Embassy's official roster of 
                recommended legal service providers for American citizens in The Bahamas. This 
                recognition reflects our commitment to serving U.S. nationals with the highest 
                standards of legal excellence.
              </p>
              <p className="text-gold text-sm font-medium mt-4">
                Continuously recommended since 2008
              </p>
            </div>

            {/* Badge */}
            <div className="flex-shrink-0 hidden lg:block">
              <div className="w-20 h-20 border border-gold/30 flex items-center justify-center">
                <div className="text-center">
                  <CheckCircle2 className="text-gold mx-auto mb-1" size={24} />
                  <span className="text-gold text-[10px] font-semibold uppercase">Verified</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Other Affiliations Grid */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4"
        >
          {trustSeals.filter(seal => !seal.featured).map((seal, index) => (
            <motion.div
              key={seal.id}
              variants={fadeUpVariant}
              data-testid={`trust-seal-${seal.id}`}
              className="group bg-white border border-limestone hover:border-gold/30 p-6 transition-all text-center"
            >
              {/* Icon placeholder */}
              <div className="w-12 h-12 mx-auto mb-4 bg-navy/5 group-hover:bg-gold/10 flex items-center justify-center transition-colors">
                {index === 0 && <Scale className="text-gold" size={24} />}
                {index === 1 && <Building2 className="text-gold" size={24} />}
                {index === 2 && <Globe className="text-gold" size={24} />}
                {index === 3 && <Building2 className="text-gold" size={24} />}
                {index === 4 && <Award className="text-gold" size={24} />}
              </div>
              
              <h4 className="font-serif text-sm text-navy mb-1 leading-tight">
                {seal.name}
              </h4>
              <p className="text-gold text-[10px] font-semibold uppercase tracking-wider mb-2">
                {seal.subtitle}
              </p>
              <p className="text-slate-400 text-[11px]">
                {seal.year}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* Trust Statement */}
        <motion.p
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUpVariant}
          className="text-center text-slate-500 text-sm mt-10 max-w-2xl mx-auto"
        >
          Our affiliations and accreditations reflect three decades of commitment to legal excellence, 
          professional integrity, and service to the Bahamian and international community.
        </motion.p>
      </div>
    </section>
  );
};

// Testimonials Carousel Section
const TestimonialsSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const nextTestimonial = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const slideVariants = {
    enter: (direction) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (direction) => ({
      x: direction < 0 ? 300 : -300,
      opacity: 0
    })
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section id="testimonials" data-testid="testimonials-section" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUpVariant}
          className="text-center mb-16"
        >
          {/* US Embassy Badge */}
          <div className="inline-flex items-center gap-2 bg-navy/5 px-4 py-2 mb-6">
            <Flag className="text-gold" size={16} />
            <span className="text-navy text-xs font-semibold uppercase tracking-wider">
              Recommended by the U.S. Embassy Nassau
            </span>
          </div>
          
          <h2 className="font-serif text-4xl md:text-5xl text-navy tracking-tight mb-6">
            Client Testimonials
          </h2>
          <div className="gold-line mx-auto" />
        </motion.div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-4xl mx-auto">
          {/* Quote Icon */}
          <div className="absolute -top-8 left-0 md:left-8 opacity-10">
            <Quote className="text-navy" size={120} />
          </div>

          {/* Carousel Content */}
          <div className="relative min-h-[350px] md:min-h-[300px] overflow-hidden">
            <AnimatePresence initial={false} custom={direction} mode="wait">
              <motion.div
                key={currentIndex}
                custom={direction}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className="absolute inset-0 flex flex-col items-center justify-center px-4 md:px-16"
                data-testid={`testimonial-${currentIndex + 1}`}
              >
                {/* Stars */}
                <div className="flex gap-1 mb-6">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="text-gold fill-gold" size={20} />
                  ))}
                </div>

                {/* Quote */}
                <blockquote className="text-center mb-8">
                  <p className="font-serif text-xl md:text-2xl text-navy leading-relaxed italic">
                    "{currentTestimonial.quote}"
                  </p>
                </blockquote>

                {/* Attribution */}
                <div className="text-center">
                  <p className="text-navy font-semibold text-lg">{currentTestimonial.name}</p>
                  <p className="text-slate-500 text-sm">{currentTestimonial.role}</p>
                  <p className="text-slate-400 text-sm">{currentTestimonial.location}</p>
                  
                  {currentTestimonial.isUSEmbassyReferred && (
                    <div className="inline-flex items-center gap-1.5 mt-3 text-gold text-xs font-medium">
                      <CheckCircle2 size={14} />
                      <span>U.S. Embassy Referred Client</span>
                    </div>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prevTestimonial}
              data-testid="testimonial-prev-btn"
              className="w-12 h-12 border border-limestone flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={20} />
            </button>
            
            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setDirection(index > currentIndex ? 1 : -1);
                    setCurrentIndex(index);
                  }}
                  data-testid={`testimonial-dot-${index + 1}`}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentIndex ? "bg-gold w-6" : "bg-limestone hover:bg-gold/50"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            
            <button
              onClick={nextTestimonial}
              data-testid="testimonial-next-btn"
              className="w-12 h-12 border border-limestone flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

// Case Studies Section
const CaseStudiesSection = () => {
  return (
    <section id="case-studies" data-testid="case-studies-section" className="py-24 md:py-32 bg-alabaster">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="mb-16 md:mb-20"
        >
          <motion.div variants={fadeUpVariant} className="flex flex-wrap items-center gap-4 mb-4">
            <p className="text-gold text-xs font-semibold uppercase tracking-[0.25em]">
              Proven Results
            </p>
            <div className="flex items-center gap-2 bg-navy text-white px-3 py-1.5">
              <Flag size={12} />
              <span className="text-xs font-medium uppercase tracking-wider">U.S. Embassy Recommended</span>
            </div>
          </motion.div>
          <motion.h2
            variants={fadeUpVariant}
            className="font-serif text-4xl md:text-5xl text-navy tracking-tight mb-6"
          >
            Case Study Highlights
          </motion.h2>
          <motion.div variants={fadeUpVariant} className="gold-line" />
          <motion.p
            variants={fadeUpVariant}
            className="mt-6 text-slate-600 text-lg max-w-2xl"
          >
            A selection of successful matters representing U.S. citizens and businesses 
            referred by the United States Embassy in Nassau.
          </motion.p>
        </motion.div>

        {/* Case Studies Grid */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid md:grid-cols-2 gap-6"
        >
          {caseStudies.map((study) => {
            const IconComponent = study.icon;
            return (
              <motion.article
                key={study.id}
                variants={fadeUpVariant}
                data-testid={`case-study-${study.id}`}
                className="group bg-white border border-limestone hover:border-gold/30 transition-all overflow-hidden"
              >
                {/* Header */}
                <div className="p-6 md:p-8 border-b border-limestone/50">
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <div className="w-12 h-12 bg-navy/5 group-hover:bg-gold/10 flex items-center justify-center transition-colors">
                      <IconComponent className="text-gold" size={24} />
                    </div>
                    {study.isUSEmbassyReferred && (
                      <div className="flex items-center gap-1.5 bg-navy/5 px-2.5 py-1">
                        <Flag className="text-gold" size={12} />
                        <span className="text-navy text-[10px] font-semibold uppercase tracking-wider">Embassy Referred</span>
                      </div>
                    )}
                  </div>
                  <span className="text-gold text-xs font-semibold uppercase tracking-wider">
                    {study.category}
                  </span>
                  <h3 className="font-serif text-xl md:text-2xl text-navy mt-2 group-hover:text-gold transition-colors">
                    {study.title}
                  </h3>
                </div>

                {/* Body */}
                <div className="p-6 md:p-8">
                  <p className="text-slate-600 text-sm leading-relaxed mb-6">
                    {study.description}
                  </p>
                  
                  {/* Outcome */}
                  <div className="flex items-start gap-3 p-4 bg-navy/5">
                    <CheckCircle2 className="text-gold flex-shrink-0 mt-0.5" size={18} />
                    <div>
                      <p className="text-navy text-xs font-semibold uppercase tracking-wider mb-1">Outcome</p>
                      <p className="text-navy font-medium">{study.outcome}</p>
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUpVariant}
          className="text-center mt-12"
        >
          <p className="text-slate-500 mb-4">
            Ready to discuss your legal needs?
          </p>
          <a
            href="#contact"
            data-testid="case-studies-cta"
            className="inline-flex items-center gap-2 bg-navy text-white px-8 py-4 text-sm font-semibold uppercase tracking-[0.15em] hover:bg-navy-light transition-colors"
          >
            Request a Consultation
            <ArrowRight size={16} />
          </a>
        </motion.div>
      </div>
    </section>
  );
};

// Contact CTA Section
const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', message: '' });
    }, 1000);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section id="contact" data-testid="contact-section" className="py-24 md:py-32 bg-alabaster">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.p
              variants={fadeUpVariant}
              className="text-gold text-xs font-semibold uppercase tracking-[0.25em] mb-4"
            >
              Get in Touch
            </motion.p>
            <motion.h2
              variants={fadeUpVariant}
              className="font-serif text-4xl md:text-5xl text-navy tracking-tight mb-6"
            >
              Request a Consultation
            </motion.h2>
            <motion.div variants={fadeUpVariant} className="gold-line mb-8" />
            
            <motion.p
              variants={fadeUpVariant}
              className="text-slate-600 text-lg leading-relaxed mb-10"
            >
              Whether you're navigating a complex transaction or seeking trusted legal counsel, 
              we're here to help. Contact us to schedule a confidential consultation.
            </motion.p>

            <motion.div variants={staggerContainer} className="space-y-6">
              <motion.div variants={fadeUpVariant} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-navy/5 flex items-center justify-center">
                  <MapPin className="text-gold" size={20} />
                </div>
                <div>
                  <p className="text-navy font-medium">Visit Our Office</p>
                  <p className="text-slate-500 text-sm">Nassau, New Providence, The Bahamas</p>
                </div>
              </motion.div>

              <motion.div variants={fadeUpVariant} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-navy/5 flex items-center justify-center">
                  <Phone className="text-gold" size={20} />
                </div>
                <div>
                  <p className="text-navy font-medium">Call Us</p>
                  <a href="tel:+12423222000" className="text-slate-500 text-sm hover:text-gold transition-colors">
                    +1 (242) 322-2000
                  </a>
                </div>
              </motion.div>

              <motion.div variants={fadeUpVariant} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-navy/5 flex items-center justify-center">
                  <Mail className="text-gold" size={20} />
                </div>
                <div>
                  <p className="text-navy font-medium">Email Us</p>
                  <a href="mailto:info@seymourlaw.com" className="text-slate-500 text-sm hover:text-gold transition-colors">
                    info@seymourlaw.com
                  </a>
                </div>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUpVariant}
          >
            {submitted ? (
              <div className="bg-white p-10 border border-limestone text-center">
                <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="text-gold" size={32} />
                </div>
                <h3 className="font-serif text-2xl text-navy mb-4">Thank You</h3>
                <p className="text-slate-600">
                  We've received your message and will be in touch shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} data-testid="contact-form" className="bg-white p-8 md:p-10 border border-limestone">
                <div className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-navy text-sm font-medium mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      data-testid="contact-name-input"
                      className="w-full px-4 py-3 border border-limestone bg-alabaster focus:border-gold focus:outline-none transition-colors"
                      placeholder="Your full name"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-navy text-sm font-medium mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        data-testid="contact-email-input"
                        className="w-full px-4 py-3 border border-limestone bg-alabaster focus:border-gold focus:outline-none transition-colors"
                        placeholder="you@example.com"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-navy text-sm font-medium mb-2">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        data-testid="contact-phone-input"
                        className="w-full px-4 py-3 border border-limestone bg-alabaster focus:border-gold focus:outline-none transition-colors"
                        placeholder="+1 (242) 000-0000"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-navy text-sm font-medium mb-2">
                      How Can We Help? *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={4}
                      data-testid="contact-message-input"
                      className="w-full px-4 py-3 border border-limestone bg-alabaster focus:border-gold focus:outline-none transition-colors resize-none"
                      placeholder="Tell us about your legal needs..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    data-testid="contact-submit-btn"
                    className="w-full bg-navy text-white py-4 text-sm font-semibold uppercase tracking-[0.15em] hover:bg-navy-light transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? 'Sending...' : 'Submit Request'}
                  </button>

                  <p className="text-slate-500 text-xs text-center">
                    Your information is kept strictly confidential.
                  </p>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer data-testid="footer" className="bg-navy py-16 md:py-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gold flex items-center justify-center">
                <span className="text-navy font-serif text-xl font-bold">S</span>
              </div>
              <span className="font-serif text-2xl text-white">Seymour Law</span>
            </div>
            <p className="text-white/60 leading-relaxed max-w-md mb-6">
              Trusted commercial legal counsel in The Bahamas since 1995. 
              Providing world-class expertise with personalized attention.
            </p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-gold rounded-full" />
              <span className="text-gold text-sm">Nassau, New Providence, The Bahamas</span>
            </div>
          </div>

          {/* Practice Areas */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Practice Areas</h4>
            <ul className="space-y-3">
              {practiceAreas.slice(0, 4).map((area) => (
                <li key={area.id}>
                  <a href="#practice-areas" className="text-white/60 text-sm hover:text-gold transition-colors">
                    {area.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3">
              <li>
                <a href="tel:+12423222000" className="text-white/60 text-sm hover:text-gold transition-colors">
                  +1 (242) 322-2000
                </a>
              </li>
              <li>
                <a href="mailto:info@seymourlaw.com" className="text-white/60 text-sm hover:text-gold transition-colors">
                  info@seymourlaw.com
                </a>
              </li>
              <li className="pt-4">
                <a 
                  href="#contact" 
                  className="inline-block border border-gold text-gold px-6 py-3 text-xs font-semibold uppercase tracking-[0.15em] hover:bg-gold hover:text-navy transition-all"
                >
                  Request Consultation
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} Seymour Law. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-white/40 text-sm hover:text-gold transition-colors">Privacy Policy</a>
            <a href="#" className="text-white/40 text-sm hover:text-gold transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// Main App Component
function App() {
  return (
    <div className="App bg-alabaster">
      <Navbar />
      <main>
        <HeroSection />
        <PracticeAreasSection />
        <AboutSection />
        <WhyUsSection />
        <TrustSealsSection />
        <TestimonialsSection />
        <CaseStudiesSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
